import { StatusBar } from 'expo-status-bar';
import { StyleSheet, ScrollView, Text, View, Button, TextInput, Image, TouchableHighlight, TouchableOpacity } from 'react-native';
import Navigation from './Components/Navigation/Navigation';

export default function App() {
  return (
    <Navigation />
  )
};